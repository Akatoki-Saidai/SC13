"""robot_car_auto controller"""
import cv2
import numpy as np
from math import pi,sin
from vehicle import Driver
from controller import GPS, Node
from controller import Robot,Motor,DistanceSensor
""" ロボットカークラス """

TIME_STEP = 32
robot = Robot()

"""モーターを取得"""
motor_left = robot.getMotor("motor_left")
motor_right = robot.getMotor("motor_right")
motor_left.setPosition(float("inf"))
motor_right.setPosition(float("inf"))
motor_left.setVelocity(0.0)
motor_right.setVelocity(0.0)

F = 2.0   # frequency 2 Hz
t = 0.0   # elapsed simulation time
"""距離センサーを取得"""
distance_sensor = robot.getDevice("distance sensor")#距離センサー
distance_sensor.enable(TIME_STEP)
"""gpsを取得"""
gps = robot.getDevice("gps")
gps.enable(TIME_STEP)
"""加速度センサーを取得"""
accelerometer = robot.getDevice("accelerometer")
accelerometer.enable(TIME_STEP)
"""カメラを取得"""
camera = robot.getDevice("camera")
camera.enable(TIME_STEP)
camera_width  = camera.getWidth()
camera_height = camera.getHeight()
camera_fov    = camera.getFov()

"""1ループで32[ms]シミュレーションを進める。この時間を短くすると計算精度up。けどシミュレーションは遅くなる。"""
while robot.step(TIME_STEP) != -1:
    position = sin(t * 2.0 * pi * F)
    motor_left.setVelocity(1)
    motor_right.setVelocity(1)
    t += TIME_STEP / 1000.0
    
    """現在の物体との距離を取得"""
    distance_value = distance_sensor.getValue()
    print("物体までの距離は: ",distance_value)
    """現在の位置を取得"""
    gps_values = gps.getValues()
    print("現在の位置は: %g %g %g" % (gps_values[0], gps_values[1], gps_values[2]))
    """現在の加速度を取得"""
    accelerometer_values = accelerometer.getValues()
    print(f"加速度は:x = {accelerometer_values[0]} , y = {accelerometer_values[1]} , z = {accelerometer_values[2]}")
    