/*　wheel1.c　*/
#include 
#include <webots/motor.h>
#include <webots/robot.h>

/* main関数 */
int main() {
  WbDeviceTag motor_left, motor_right; /* デバイスの宣言 */

  wb_robot_init();  /* webotsの初期化 */  

  motor_left  = wb_robot_get_device("motor_left");  /* デバイスの取得 */
  motor_right = wb_robot_get_device("motor_right");   
  wb_motor_set_position(motor_left,  INFINITY);     /*　モータ位置の設定           */
  wb_motor_set_position(motor_right, INFINITY);     /* 速度制御時はINFINITYに設定 */

  while (wb_robot_step(64) != -1) {
    wb_motor_set_velocity(motor_left,  3.0);        /* 回転速度の設定 [rad/s]    */
    wb_motor_set_velocity(motor_right, 5.0); 
  } 
  
  wb_robot_cleanup(); /* webotsの終了処理 */

  return 0;
}