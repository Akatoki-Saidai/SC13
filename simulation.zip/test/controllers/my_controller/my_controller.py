from controller import Robot
import cv2

robot = Robot()

robot.left(speed=0.3)